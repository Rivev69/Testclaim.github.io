<?php
$emailku = 'GANTIEMAIL'; // GANTI EMAIL KAMU DISINI
?>